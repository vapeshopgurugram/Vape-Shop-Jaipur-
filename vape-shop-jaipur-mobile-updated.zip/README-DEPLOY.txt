Vape Shop Jaipur - Static Website (Cloudflare Pages ready)

Deploy steps:
1. Cloudflare Dashboard -> Workers & Pages -> Create -> Pages -> Upload assets
2. Project name: vapeshopsjaipur (ya koi bhi naam)
3. Is zip ke ANDAR ke saare files/folders upload karein (zip khud nahi, uska content)
   - Ya "Drag and drop" mein ye sab files select karke daal dein
4. Deploy click karein - site turant live ho jayegi
5. Custom domain (vapeshopsjaipur.com): Pages project -> Custom domains -> Add domain

Note: Saari 124 product pages, images, sitemap.xml sab static hain - koi server ki zaroorat nahi.
